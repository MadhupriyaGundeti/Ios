import UIKit

var greeting = "Hello, playground"
print("Welcome to Ios")
