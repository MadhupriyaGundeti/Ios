//
//  ViewController.swift
//  Hello2App
//
//  Created by Gundeti,Madhupriya on 8/30/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameOutlet: UITextField!
    
    @IBOutlet weak var diaplayLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func submitButtonClicked(_ sender: UIButton) {
        //Read the text from text field and assign it to a local variable.
        var name = nameOutlet.text! // exclamation is to unwrap the text.;
        
        //Assign the data(name) to the the diaplay label.
        diaplayLabel.text = "Hello, \(name)!";
        
        
    }
}

