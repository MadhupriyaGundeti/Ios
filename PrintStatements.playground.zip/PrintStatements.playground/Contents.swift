import UIKit

var greeting = "Hello, playground"
print("Hello World!")
print(greeting)

print("Hi",10,10.5)
print("Hello World!" + greeting)
print("Hello World \(greeting)")
var age=12  // can change variable value
print("My age is \(age)") // String interpolation

//print("My age is " + age) concatenation of different data types are not allowed

print("You are \(age) years old and in another \(age) years, you will be \(age*2)")
print("""
Hello
World!
from the US
""")
print("Hello All, \rWelcome to Swift programming")
let welcomemessage: String = "Hello!"
print(welcomemessage , "All")
//welcomemeaasge = "Good Bye" cannot change the constants.
var name: String = "John"
print(name,2,"Smith")
name="Bob"
print(name)
print("Welcome to Swift programming")
print("Fall 2021")
print("*********")
print("Welcome to Swift programming", terminator: "$")
print("Fall 2022")
print("The list of numbers are ")
print(1,2,3,4,5,6)
print("The new pattern is ")
print(1,2,3,4,5,6, separator: "_")
var mobileBrand = "Apple"
mobileBrand = "Samsung"
print(mobileBrand)
let pi = 3.14
print(pi)
var age1 : Int = 23
age1 = age1*2
print(age1)
var aweMessage = "This is Superb!"
print(aweMessage)
print ("aweMessage")
var course1 = "IOS"
var course2 = "Java"
print(course1,course2)
print(course1, "-", course2)
print(10,20,30)
print(12.5,15.5)
print("course1,\(course2)")
var httpError = (errorCode : 404, errorMessage : "Page not found")
print(httpError)
print(httpError.errorCode , terminator : ":")
print(httpError.errorMessage)
var name1 = ("John","Smith")
var fname = name1.0
var lname = name1.1
print(fname ,  terminator : ":")
print(lname)
var cricketkit = ("handGloves","Helmet",("bat","ball"))
print(cricketkit.0)
print(cricketkit.1)
print(cricketkit.2.0)
print(cricketkit.2.1)
var origin = (x : 0, y : 0)
var point = origin
print(point)
let city = (name:"Maryville",population: 11,000)
let (cityName, cityPopulation) = (city.0,city.1)
print(cityName)
print(cityPopulation)
let groceries = ("Bread","onions")
print(groceries.0)
print(groceries.1)
print(type(of: groceries))
var fname1 = "Joe"
var lname1 = "Root"
(fname1,lname1) = (lname1,fname1)
print("First name is \(fname1) and Last name is \(lname1)")
